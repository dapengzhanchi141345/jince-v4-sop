#!/usr/bin/env python3
"""
试卷智能识别引擎 - 基于 Agnes AI 2.0 Flash 多模态模型
将试卷图片发送给 Agnes AI，获取精确的题目内容和学生答案识别
"""
import base64, json, os, sys, requests
from pathlib import Path

API_KEY = "sk-JWX2DlNAKaoBTIdtw4ZR5wLPWWaAvDJ46JNjnmsJmpSubN99"
API_URL = "https://apihub.agnes-ai.com/v1/chat/completions"

def encode_image(image_path):
    """将图片编码为base64 data URI"""
    path = Path(image_path)
    if not path.exists():
        return None, f"文件不存在: {image_path}"
    
    suffix = path.suffix.lower()
    mime_map = {'.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', 
                '.png': 'image/png', '.bmp': 'image/bmp',
                '.gif': 'image/gif', '.webp': 'image/webp'}
    mime = mime_map.get(suffix, 'image/jpeg')
    
    with open(path, 'rb') as f:
        b64 = base64.b64encode(f.read()).decode('utf-8')
    
    return f"data:{mime};base64,{b64}", None

def analyze_exam_images(image_paths, prompt_type="grade"):
    """
    使用 Agnes AI 分析试卷图片
    prompt_type: "ocr"=提取文字, "grade"=逐题评分, "answers"=仅提取答案
    """
    content = []
    
    prompts = {
        "ocr": """请仔细识别这张试卷图片中的所有文字内容，严格按照格式输出：

【试卷信息】科目、年级、考试时间
【题目内容与学生答案】逐题列出（题号、题型、分值、题目原文、学生答案、标准答案建议）

如果有计算题，请详细提取学生的计算过程。如果有多页请标注页码。""",
        
        "grade": """你是一位严格的阅卷教师。请逐题评分：

| 题号 | 题型 | 分值 | 学生答案 | 标准答案 | 得分 | 扣分原因 |
计算题必须分步评分（公式分+代入分+结果分+单位分）
最后给出：总分、正确率、评级（优秀≥85/良好≥70/及格≥60/需努力<60）、薄弱知识点分析""",
        
        "answers": """仅提取学生填写的答案，忽略题目内容。按题号列出学生答案。"""
    }
    
    content.append({"type": "text", "text": prompts.get(prompt_type, prompts["grade"])})
    
    for img_path in image_paths:
        data_uri, err = encode_image(img_path)
        if err:
            print(f"  [警告] {err}", file=sys.stderr)
            continue
        content.append({"type": "image_url", "image_url": {"url": data_uri}})
    
    payload = {
        "model": "agnes-2.0-flash",
        "messages": [{"role": "user", "content": content}],
        "max_tokens": 16384
    }
    
    headers = {
        "Authorization": f"Bearer {API_KEY}",
        "Content-Type": "application/json"
    }
    
    try:
        resp = requests.post(API_URL, json=payload, headers=headers, timeout=300)
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"], None
        else:
            return None, f"API错误 {resp.status_code}: {resp.text[:200]}"
    except Exception as e:
        return None, f"请求异常: {str(e)}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 exam_reader.py <图片路径1> [图片路径2] ... [--mode grade|ocr|answers]")
        sys.exit(1)
    
    images = []
    mode = "grade"
    for arg in sys.argv[1:]:
        if arg in ("grade", "ocr", "answers"):
            mode = arg
            continue
        images.append(arg)
    
    print(f"[exam_reader] 分析 {len(images)} 张图片, 模式: {mode}")
    result, error = analyze_exam_images(images, mode)
    
    if error:
        print(f"[错误] {error}")
        sys.exit(1)
    
    print(result)
