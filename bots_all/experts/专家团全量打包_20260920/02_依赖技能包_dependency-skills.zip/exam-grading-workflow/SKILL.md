---
name: exam-grading-workflow
agent_created: true
description: >
  试卷智能阅卷工作流。当用户上传试卷图片要求批改/评分时使用。 通过 Agnes AI 2.0 Flash 多模态模型进行图片识别与评分。
  支持单张/多张图片，返回逐题评分表、分步解析、学情分析。
when:
  - 用户上传试卷图片要求批改/评分
  - 用户说"批改""评分""阅卷""改卷"等关键词
  - 用户需要AI识别试卷内容并自动给分
  - 用户要求分析学生成绩/学情/薄弱点
trigger_keyword: 批改, 评分, 阅卷, 改卷, 试卷, 考试批改, 阅卷
---

# 试卷智能阅卷工作流

## 一句话用法

> 用户发试卷图片 → 调用 exam_reader.py（Agnes AI 多模态识别）→ 逐题评分 → 出报告

## 核心流程

```
Step 1: 接收用户发来的试卷图片路径
Step 2: 调用 exam_reader.py 分析图片
Step 3: 根据分析结果给出逐题评分表
Step 4: 输出学情分析报告
```

## 调用方式

```bash
# 评分模式（默认）
python3 scripts/exam_reader.py /path/to/image.jpg

# OCR模式（仅提取文字）
python3 scripts/exam_reader.py /path/to/image.jpg ocr

# 多张图片
python3 scripts/exam_reader.py /path/to/page1.jpg /path/to/page2.jpg

# 仅提取学生答案
python3 scripts/exam_reader.py /path/to/image.jpg answers
```

## 工作流程详解

### 1. 接收图片
- 确认用户发来的图片是标准答案卷还是学生答题卷
- 记录所有图片路径（支持 jpg/png/bmp/webp）

### 2. 调用识别引擎
- 执行 `python3 scripts/exam_reader.py <图片路径1> <图片路径2> ...`
- 脚本将图片编码为 base64，调用 Agnes AI 2.0 Flash 多模态模型
- 等待返回结果（约 10-60 秒）

### 3. 评分与输出
- 从返回结果中提取逐题评分表
- 整理为结构化报告：
  - 总得分/满分/正确率/评级
  - 逐题得分明细
  - 计算题分步评分
  - 薄弱知识点分析
  - 学习建议

### 4. 文件输出（可选）
- 可将评分结果保存为 CSV 成绩表
- 可生成完整评级报告 HTML

## 注意事项
- 确保图片清晰可辨，手写体越清晰识别越准
- 多页试卷请一次性发送所有图片
- 如需标准答案，可先发标准答案卷再发学生答题卷
- 每次调用 RPM 控制在 20 以内
- 大图片（>5MB）建议压缩后识别
