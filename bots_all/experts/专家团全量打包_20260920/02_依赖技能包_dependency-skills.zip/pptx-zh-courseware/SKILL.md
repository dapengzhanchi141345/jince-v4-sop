---
name: pptx-zh-courseware
description: 用 python-pptx 程序化生成中文培训/教学课件（16:9 深色科技风），并自动校验排版越界与文本溢出。适用于教师培训、政策宣讲、校本教研、公开课等需要美观 PPTX 的场景。触发词：生成PPTX、做课件、培训课件、PPT课件、课件排版校验。
agent_created: true
---

# 中文课件 PPTX 生成工作流

## 何时用
用户要"课件/PPT/培训材料"且需要可编辑的 .pptx 文件时。若用户只要放映效果，优先做单文件 HTML 演示（支持缩放+计时器），PPTX 作为备份。

## 环境
```bash
# 隔离 venv（勿全局安装）
C:/Users/ASUS/.workbuddy/binaries/python/envs/default/Scripts/pip.exe install python-pptx
C:/Users/ASUS/.workbuddy/binaries/python/envs/default/Scripts/python.exe script.py
```
产出文件一律放 **E 盘**，禁止 C 盘。

## 一、骨架（必须按此搭）
```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE

FONT = "微软雅黑"
prs = Presentation()
prs.slide_width, prs.slide_height = Inches(13.333), Inches(7.5)   # 16:9
BLANK = prs.slide_layouts[6]
ML = MR = 0.62; CW = 13.333 - ML - MR
```

三个 helper 解决 90% 的活：
- `rect(sl,x,y,w,h,fill,line,shape)` — 背景/卡片/分割线/装饰椭圆
- `text(sl,x,y,w,h,runs,align,anchor,spacing,space_after)` — runs 支持 `[(文本,字号,颜色,加粗)]`，**二维数组表示多段**
- `card_text(...)` — 卡片（左侧 4.5% 宽的强调竖条 + 标题 + 正文块）

配色（深色科技风，投影友好）：
```
BG=0B1428  PANEL=162544  CYAN=22D3EE  BLUE=5B9BFF  GOLD=FBBF24
GREEN=34D399  RED=F87171  PURPLE=A78BFA  T1=EEF4FF  T2=A9BBD6  T3=6B7F9E
```
页脚统一：`footer(sl, idx)` 画线 + 主题名 + `NN / 14` 页码。

## 二、排版高度公式（中文，务必套用）
- 字符宽度当量：**中文/全角/emoji = 1.0 em，西文数字 = 0.52 em，空格 = 0.28 em**
- 每行可放中文字数 `per_line = (宽_in × 72) ÷ 字号 pt`
- 段落高度 `= ceil(当量数 ÷ per_line) × 字号 × 1.30 × line_spacing ÷ 72 + space_after/72`

卡片内部可用正文高：
```
可用 = 卡片高 − 0.17(上边距) − 0.32(有 tag 时) − head 区 − 0.14(下边距)
head 区：单行标题 0.40；可能换两行的长标题 0.62
```

## 三、生成后必须校验

### 3.1 数值校验（快，先做）
写 `_verify.py`：遍历所有 shape，算两件事
1. **越界**：`left<0 / top<0 / right>SW / bottom>SH`。例外：无文字的装饰椭圆（光晕）允许出血 —— 判断条件用 `not sh.has_text_frame or not sh.text_frame.text.strip()`
2. **溢出**：按上面公式估算文本实需高度 vs 文本框声明高度，差值 > 0.12in 即报

输出 `✅ 无越界、无明显溢出` 才算合格。改高度/字号→重跑→重校验，迭代到干净。

### 3.2 ★ 渲染自检（决定性一步，不要跳过）

**数值校验查不出"好不好看"。反复翻车的根因都是盲做 —— 只能靠公式猜版面，看不到真实渲染。**
本机装了 Microsoft PowerPoint，用 `pywin32` COM 把 pptx 导出成 PNG，逐页肉眼验收：

```bash
uv pip install --python "<venv>/Scripts/python.exe" --index-url https://pypi.tuna.tsinghua.edu.cn/simple pywin32
```
```python
import win32com.client as win32, os
app  = win32.Dispatch('PowerPoint.Application')   # WPS 用 'Kwpp.Application'
pres = app.Presentations.Open(os.path.abspath(pptx), WithWindow=False)
for i, s in enumerate(pres.Slides, 1):
    s.Export(os.path.join(outdir, f'p{i:02d}.png'), 'PNG', 1600, 900)
pres.Close(); app.Quit()
```
- PowerPoint 常见路径：`C:\Program Files\Microsoft Office\root\Office16\POWERPNT.EXE`；或用 `pywin32` 直接 Dispatch 不必手填路径
- 批量导出也可 `pres.Export(dir, 'PNG', 1600, 900)`
- **导出后必须逐页 Read 图片确认**，再把 12 页拼成一张 contact sheet 一次扫完（更省 token）

这一步查出来的典型问题（公式永远发现不了）：
字体渲染与实际字宽不符导致换行溢出 / 水印或装饰被画布裁切 / 文字压在深色插画上不可读 / 插画风格幼稚拉低档次 / 卡片正文贴边。

### 3.3 渲染自检替代方案
无 Office 时依次降级：LibreOffice `soffice --headless --convert-to pdf` 再转图 → `slidep screenshot`（需本地编辑器服务 `localhost:39099`）→ 只能退回数值校验并在交付时说明未做视觉验收。

## 三点五、插画：不要在 PPT 里用基本图形硬拼

用 PPT 的 `rect/circle` 硬拼具象插画（人、物、场景）**必然幼稚**，一眼看出是"拼的"。正确做法：**PIL 生成透明底 PNG，再 `add_picture` 贴进版面**。

有效技法：
- **3× 超采样**：`Image.new('RGBA', (w*3, h*3))` 画完 → `resize((w,h), LANCZOS)`，白得抗锯齿
- **柔光**：`Image.radial_gradient('L')` → `ImageOps.invert` → `point(lambda v: 255*alpha*((v/255)**k))` 当 alpha 用（k 越小光晕越散）。**k 必须 > 0**，否则 `0.0 ** 负数` 抛 ZeroDivisionError
- **软阴影**：独立层画椭圆 → `GaussianBlur` → `alpha_composite`
- **渐细曲线**：二次贝塞尔采样 48 点 → 分段 `line()`，线宽线性收细
- **文字压在插画上不可读** → 在山脚/底部加白色 alpha 渐变"雾带"托底，或把说明文字直接烘进 PNG
- ⚠️ `ImageDraw.Draw(img,'RGBA')` 是**替换不是叠加**：半透明图形要画在独立透明层再 `alpha_composite`，否则柔光处变硬边色块
- 配色统一 + **大量留白**，比堆元素高级得多

## 四、高频坑（本次踩过）
- **嵌套结构括号层数**：`[(标题, 色, [[(块1),(块2)]]), ...]` 结尾是 `)]])`（block`]`+body`]`+元组`)`+外层`]`）。少一层就是 `SyntaxError: closing ']' does not match opening '('`
- **自己写括号检查脚本时**，必须特殊处理 `"""` 三引号 docstring，否则在第 2 行就误报 unclosed string
- Edit 工具替换多行代码块时，注意保留/去掉缩进，否则 IndentationError
- 文本框声明高度小于实际不影响显示（PPT 会溢出显示），但会压到下方元素 —— 校验器报出的"溢出"要判断是否真的超出**卡片**边界
- emoji（🇨🇳🎓🏫）在微软雅黑下可正常渲染，适合做小图标，省去插图
- **中文实际字宽 ≈ 字号 × 1.33**（不是 1.0）。按 1.0em 估宽会窄 20%，窄卡片/标签必然换行溢出
- **水印/装饰画布裁切**：圆形装饰要满足 `x−r ≥ 0 且 x+r ≤ W 且 y−r ≥ 0 且 y+r ≤ H`，否则被裁（本次「责」字水印就是这么缺了半个头）
- **水印要压到背景之上、内容之下**：`add_picture` 默认加在最顶层，需手动搬元素 —— `spTree.remove(el); spTree.insert(3, el)`（索引 2 是背景）
- **文档属性**：python-pptx 默认写库的垃圾值（作者 `Steve Canny`、创建时间 2013 年），交付前务必清：
  `cp.author/last_modified_by/title/subject/created/modified` 逐个赋值
- **`slidep upsert-dsl` 不是幂等替换而是追加**，且 `.slidep/` 项目仓库会残留旧页 —— 重跑会让页数翻倍、页面顺序错乱。要用它必须 `rm -rf .slidep <pptx>` 一起删干净。它的 `create/upsert` 还依赖本地编辑器服务 `localhost:39099`，该服务没起时整条链路不可用 → 优先用 python-pptx 原生生成

## 五、内容组织（培训类课件通用结构）
政策/理念类培训按"高度 → 干货 → 红线 → 行动"四段：
1. 时代信号（会议/大会事实）
2. 政策坐标系（时间轴，3—4 份文件递进）
3. 实操场景（**每张干货页必配 ❌错误 vs ✅正确 对比**——最有效的呈现形式）
4. 红线底线 + 判例互动
5. 校本行动路线（月度四步走）+ 资源清单

配套产出四件套效果最好：
| 文件 | 用途 |
|:--|:--|
| `xxx.html` 网页课件 | 主讲放映（自带计时器/页码记忆） |
| `xxx.pptx` | 备份/送审/二次编辑 |
| `分学科速查卡.html` | 发教研组，提示词可一键复制 |
| `讲师手册.html` | 逐页口播要点+时间卡点+出处对照 |

## 六、引用政策类内容
必须 WebSearch 核实原文名称、发文单位、文号、时间，并在手册里列"事实—出处"对照表。方向性表述（如"拟纳入职称评审"）不能说成"已强制"。
