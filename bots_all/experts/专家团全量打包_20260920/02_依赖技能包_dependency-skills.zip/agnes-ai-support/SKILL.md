---
name: agnes-ai-support
version: "1.1.0"
description: |
  Agnes AI 全模态免费 API 接入技能 — 文本/图像/视频 全部免费（RPM 20以内）。
  Base URL: https://apihub.agnes-ai.com/v1（现账号所在平台）。支持图片理解、Tool Calling、
  Thinking 模式、流式输出。兼容 OpenAI 格式。**文本首选 agnes-3.0-flash**（512K上下文/65K输出）。
  已封装零依赖本地客户端：E:\workbuddy\workbuddy系统盘\agnes-api\（含 --selftest 自检）。
  含「接入 WorkBuddy 自定义模型」完整排错：模型 id 必须=真实模型名、多 Key 分配不同模型名、
  models.json 三处路径同步、只读保护、热加载 —— 以及体检脚本 check_workbuddy_models.py。
read_when:
  - 用户需要生成图片、视频等多媒体内容
  - 用户提到 Agnes AI、免费 API、生图、生视频
  - 用户需要多模态 AI 能力支持
  - 用户需要调用第三方 AI 模型 API
  - Agnes 的 Key 在 WorkBuddy 里"连不上 / 只通一个 / 模型不存在 / 503"
trigger_keyword: agnes, 生图, 生视频, agnes-image, agnes-video, 免费API, apihub
config:
  api_key_env: AGNES_API_KEY
  api_base_url: https://apihub.agnes-ai.com/v1
  api_key_path: C:\Users\ASUS\.workbuddy\skills\agnes-ai-support\.agnes-key
---

# Agnes AI 全模态免费 API 技能

> **API Base URL**: `https://apihub.agnes-ai.com/v1`
> **免费限制**: RPM 20（每分钟 20 次请求，按账号统计），无其他限制
> **兼容格式**: OpenAI Chat Completions
> **注册获取 Key**: https://platform.agnes-ai.com

## 一、模型速查

| 用途 | 模型名称 | 端点 |
|:----|:---------|:-----|
| **文本首选·Agent/编程/工具编排** | **`agnes-3.0-flash`** | `POST /v1/chat/completions` |
| 通用对话/高并发 | `agnes-1.5-flash` | `POST /v1/chat/completions` |
| **编程/Agent/推理/图片理解（上一代）** | `agnes-2.0-flash` | `POST /v1/chat/completions` |
| 图像生成（推荐） | `agnes-image-2.1-flash` | `POST /v1/images/generations` |
| 图像生成（标准） | `agnes-image-2.0-flash` | `POST /v1/images/generations` |
| 视频生成 | `agnes-video-v2.0` | `POST /v1/videos` |

## 二、文本模型 API

### agnes-3.0-flash（当前默认，2026-09-11 实测全通过）
- **规格**: 512K 上下文 / 65,536 Token 最大输出；输入支持文本 + 图像 URL
- **端点**: `/v1/chat/completions`、`/v1/responses`、Anthropic 兼容 `/v1/messages`
- **实测能力**: 文本对话 ✅ 流式 ✅ Thinking 开关 ✅ Tool Calling ✅ 图像理解 ✅
- **默认带思考链**：响应里有 `reasoning_content` 字段（独立计费为 reasoning_tokens）。
  不需要推理时用 `chat_template_kwargs: {"enable_thinking": false}` 关闭，
  延迟从 ~7s 降到 ~1.5s，token 消耗约降 60%。
- **流式注意**：`delta` 里 `reasoning_content` 与 `content` 是两个字段，
  先流思考后流正文，取正文要过滤。

### ⚠️ 两个平台 / 两套账号（2026-09-11 实测）
| 平台 | Base URL | 本机可用 Key |
|:-----|:---------|:-------------|
| apihub | `https://apihub.agnes-ai.com/v1` | `E:\李彦明\密钥\agnes.ai.txt`、`agnes.txt`（2 个） |
| cn（官方文档站） | `https://api.agnes-ai.cn/v1` | `agnes dapengzhanchi api.txt`（1 个） |

**Key 不跨平台**：apihub 的 Key 打到 api.agnes-ai.cn 会 401，反之亦然。
三个 Key 已全部实测可用，已建密钥池自动轮换。

### 接入 WorkBuddy 模型下拉列表（已配置，2026-09-11）

**UI 管理入口**：设置 → 模型选择 → 自定义模型 → 管理自定义模型 → 添加
（界面提示"数据保存在本机 `~/.codebuddy/models.json`"，即 UI 面板读写的是 **`.codebuddy`** 路径）

**文件位置（3 处全部写入，保持一致）**：

| 路径 | 角色 | 只读保护 |
|:-----|:-----|:---------|
| `~/.workbuddy/models.json` | **【运行时真正生效】** `getUserConfigPath`：产品名含 workbuddy → 用 `.workbuddy`；否则 `.codebuddy` | **必须** |
| `~/.codebuddy/models.json` | UI 面板读写的那份 | 不需要 |
| `~/models.json` | `getModelsPath()` 用户级分支，兜底 | 不需要 |

> ⚠️ **UI 面板写的 `.codebuddy` 与运行时读的 `.workbuddy` 不自动同步** —— 这是最容易踩的坑：
> 在界面里加完模型后，**必须把内容同步到 `~/.workbuddy/models.json`**，否则界面显示有、实际调不到。
> `check_workbuddy_models.py` 会同时扫描三处并告警内容不一致。

> ⚠️ **WorkBuddy 每次启动会把 `~/.workbuddy/models.json` 重置为 `[]`**
> （2026-09-12 早 07:57 实锤：重启后 2 字节）。
> **必须用 Windows 只读属性保护**，否则配置每次重启都会丢：
> ```python
> import ctypes; ctypes.windll.kernel32.SetFileAttributesW(path, 0x1)  # READONLY
> ```
> 解除（改文件前必须先做）：`SetFileAttributesW(path, 0x20)`（NORMAL）或 `attrib -R`。
> 代价：UI「管理自定义模型」面板的保存会失败（写入被拒），增删改请改文件。
>
> ✅ **改完不用重启**：应用对该文件挂了 file watcher（约 1 秒防抖），
> 实测保存后 2 秒内 `.workbuddy/cache/acc-product-config-v3.json` 即同步刷新。
> 只有下拉列表 UI 不刷新时才需要重启。

> 📍 本机 `C:\Users\ASUS\.workbuddy` 是指向 `E:\workbuddy\workbuddy系统盘\.workbuddy`
> 的 **Junction**（C 盘瘦身迁移结果）。写任一路径效果相同，排查时别忘了这个映射。

**必须是对象格式**，写成数组会被解析逻辑忽略（`parseModelsJson` 对 Array 直接返回 `{models:[]}`）。

```json
{
  "models": [{
    "id": "agnes-3.0-flash",
    "name": "Agnes 3.0 Flash",
    "vendor": "Agnes",
    "apiKey": "sk-...",
    "url": "https://apihub.agnes-ai.com/v1/chat/completions",
    "maxInputTokens": 512000,
    "maxOutputTokens": 65536,
    "supportsToolCall": true,
    "supportsImages": true,
    "supportsReasoning": true
  }]
}
```
要点：
- `url` 必须是完整路径，以 `/chat/completions` 结尾（只写到 `/v1` 不生效）。
- 🔴 **`id` 会被原样当作请求体里的 `model` 发给服务端**（只剥掉内部前缀
  `custom-local:`，实现是 `startsWith` + 单次 `slice`，**不是全局替换**，所以别想用
  `custom-local:xxx` 绕过重名）。⇒ **`id` 必须一字不差等于供应商真实模型名**。
- 🔴 **多个 Key 不能用 `-b` / `-cn` 之类后缀做区分** —— 加了后缀请求就变成
  `agnes-3.0-flash-b`，服务端直接 **HTTP 503 model_not_found**。
  正确做法：**给每个 Key 分配一个不同的、真实存在的模型名**（model id 必须全局唯一，
  UI 也强制不允许重名）。例：主号 `agnes-3.0-flash` / 备用号 `agnes-2.5-pro` /
  CN `agnes-2.5-flash`，把"主号/备用号/CN"写进 `name` 字段做区分即可。
- 用 `GET /v1/models`（带 Bearer）可拉取该 Key 真实可用模型名清单，先查再填。
- 不写 `availableModels` 字段 → 内置模型 + 自定义模型全显示；写了则只显示列出的。
- `supportsReasoning: true` 安全：实测 agnes 收到 `reasoning_effort` / `reasoning`
  参数均返回 200（未知字段被忽略）。
- **改完立刻体检**：`python E:\workbuddy\workbuddy系统盘\agnes-api\check_workbuddy_models.py --tool`
  （会检查 id 是否真实存在、Key 是否有效、是否支持 Tool Calling、配置路径是否同步、只读属性）。

### 两平台 / 三 Key 最终配置（2026-09-20 实测 3/3 全通）

| 显示名称 | 模型 ID（=真实模型名） | Base URL | Key 来源 |
|:---------|:----------------------|:---------|:---------|
| Agnes 3.0 Flash (主号) | `agnes-3.0-flash` | `https://apihub.agnes-ai.com/v1` | `agnes.ai.txt` |
| Agnes 2.5 Pro (备用号) | `agnes-2.5-pro` | `https://apihub.agnes-ai.com/v1` | `agnes.txt` |
| Agnes 2.5 Flash (CN) | `agnes-2.5-flash` | `https://api.agnes-ai.cn/v1` | `agnes dapengzhanchi api.txt` |

⚠️ **地址不可互换**：CN 的 Key 打到 apihub → `401 Invalid token`；apihub 的 Key 打到 cn → `401 无效的令牌`。
两个平台账号体系完全隔离，**不要试图把三条都指向 apihub**。

⚠️ CN 账号 `agnes-2.5-pro` 报 `403 用户额度不足`（该账号 ¥0）；**flash 系列在两边都免费**。
若备用号 `agnes-2.5-pro` 日后也提示额度不足，把它改成 `agnes-2.0-flash`（唯一不撞名的备选）。

### 本地已封装客户端（零第三方依赖，优先复用）
路径：`E:\workbuddy\workbuddy系统盘\agnes-api\`
- `agnes_client.py` — `Agnes` 类：`chat()` / `chat_full()` / `stream()` / `raw()` / `list_models()`
- `agnes.py` — CLI + `--selftest`（8 项能力自检）

```bash
python agnes.py "问题" --no-think          # 普通对话
python agnes.py "问题" --stream            # 流式
python agnes.py --img URL --no-think       # 图片理解
python agnes.py --selftest                 # 自检
```

### agnes-2.0-flash（上一代，仍可用）
- **上下文**: 512K Context / 64K Max Output
- **额外能力**: 图片理解、Tool Calling、流式输出、Thinking 模式

### Thinking 模式（两种格式均支持）

**OpenAI 格式**:
```json
{
  "chat_template_kwargs": { "enable_thinking": true }
}
```

**Anthropic 格式**:
```json
{
  "thinking": { "type": "enabled", "budget_tokens": 2048 }
}
```

### 图片理解
```json
{
  "model": "agnes-2.0-flash",
  "messages": [{
    "role": "user",
    "content": [
      { "type": "text", "text": "描述这张图片" },
      { "type": "image_url", "image_url": { "url": "https://example.com/img.jpg" } }
    ]
  }]
}
```

## 三、图像生成 API

### 端点: `POST /v1/images/generations`

### 文生图
```json
{
  "model": "agnes-image-2.1-flash",
  "prompt": "A cat on a beach at sunset",
  "size": "1024x768"
}
```

### 图生图（⚠️ image 参数必须放 extra_body 内）
```json
{
  "model": "agnes-image-2.1-flash",
  "prompt": "Transform to cyberpunk style",
  "size": "1024x768",
  "extra_body": {
    "image": ["https://example.com/input.png"],
    "response_format": "url"
  }
}
```

### 参数说明
| 参数 | 必填 | 说明 |
|:-----|:-----|:-----|
| `model` | 是 | `agnes-image-2.1-flash` 或 `agnes-image-2.0-flash` |
| `prompt` | 是 | 图像描述文本 |
| `size` | 是 | 如 `1024x768`, `1024x1024`, `768x1024`, `4096x4096`（4K已全面支持） |
| `extra_body.image` | 图生图必填 | 图片 URL 数组，**必须放 extra_body 内** |
| `extra_body.response_format` | 否 | `url` 或 `b64_json`，**必须放 extra_body 内** |
| `return_base64` | 否 | 文生图时设为 `true` 返回 Base64 |

### ⚠️ 重要约束
- **尺寸必须为 16 的倍数**（如 1024x1024）
- **response_format 必须放 extra_body 内**，否则 400 错误
- **图生图不要传 `tags: ["img2img"]`**

## 四、视频生成 API

### 端点: `POST /v1/videos`

### 创建视频任务
```json
{
  "model": "agnes-video-v2.0",
  "prompt": "A cat walking on a beach at sunset, cinematic",
  "height": 768,
  "width": 1152,
  "num_frames": 121,
  "frame_rate": 24
}
```

### 查询视频结果
```bash
# ✅ 推荐方式（必须用 video_id）
GET https://apihub.agnes-ai.com/agnesapi?video_id=<VIDEO_ID>

# ❌ 不要用 task_id 查询（会导致排队过长）
```

### 图生视频
```json
{
  "model": "agnes-video-v2.0",
  "prompt": "Animate subtle camera movement",
  "image": "https://example.com/image.png",
  "num_frames": 121,
  "frame_rate": 24
}
```

### 多图视频 / 关键帧
```json
{
  "model": "agnes-video-v2.0",
  "prompt": "Smooth transition between images",
  "extra_body": {
    "image": ["https://example.com/img1.png", "https://example.com/img2.png"],
    "mode": "keyframes"
  },
  "num_frames": 121,
  "frame_rate": 24
}
```

### 视频时长控制
**公式**: `seconds = num_frames / frame_rate`

| 目标时长 | num_frames | frame_rate |
|:--------|:-----------|:-----------|
| ~3秒 | 81 | 24 |
| ~5秒 | 121 | 24 |
| ~10秒 | 241 | 24 |
| ~18秒 | 441 | 24 |

### ⚠️ 重要约束
- `num_frames ≤ 441`，且必须满足 `8n + 1` 格式（81, 121, 161, 241, 441）
- `frame_rate` 范围 1-60
- **尺寸必须为 64 的倍数**（width/height）
- **视频长度建议不超过 15s**，否则有失败概率
- 官方建议：24FPS ≤ 15s, 30FPS ≤ 10s, 60FPS ≤ 5s

## 五、错误排查速查

| 错误码 | 原因 | 解决方案 |
|:-------|:-----|:---------|
| 400 | 参数错误 | 检查 JSON 格式、必填参数、尺寸约束（图片16倍数/视频64倍数）、response_format 位置 |
| 401 | 认证错误 | 检查 API Key 格式（`Bearer YOUR_KEY`） |
| 429 | 频率限制 | RPM 20 超限，降低请求频率 |
| 500 | 服务器错误 | 检查参数尺寸约束是否满足，稍后重试 |
| 503 | 模型不存在 / 服务繁忙 | **先查 `id` 是不是供应商真实模型名**（用 `-b`/`-cn` 等后缀区分多条会必炸）；再确认 Key 与平台匹配（apihub / cn 不可混用）；最后才考虑服务端负载 |
| 403 | 额度不足 | 该账号余额为 ¥0，`agnes-2.5-pro` 等付费模型不可用；改用 flash 系列（免费） |
| 520 | 网络异常 | 检查网络链路，稍后重试 |

## 六、常用资源

- **官方平台**: https://platform.agnes-ai.com
- **官方文档**: https://agnes-ai.com/doc/overview
- **操作手册**: https://agnes-ai.com/doc/常用接入文档
- **视频文档**: https://agnes-ai.com/doc/agnes-video-v20
- **常见问题 QA**: https://icn1d2hdv39m.feishu.cn/wiki/R7TEwjadJibD62kWeS9cubtpnPi
- **Bug 反馈**: https://github.com/AgnesAI-Labs/Agnes-AI/issues
- **进度看板**: https://github.com/users/AgnesAI-Labs/projects/1
- **官方 GitHub**: https://github.com/AgnesAI-Labs/Agnes-AI

## 七、使用示例

### 生图（用户说"帮我生成一张图片"）
1. 调用 `POST /v1/images/generations` 使用 `agnes-image-2.1-flash`
2. 参数：`prompt`（提示词）+ `size`
3. 返回的 `data[0].url` 即为图片地址

### 生视频（用户说"生成一段视频"）
1. 调用 `POST /v1/videos` 使用 `agnes-video-v2.0`
2. 参数：`prompt` + `num_frames` + `frame_rate`
3. 获取返回的 `video_id`
4. 用 `GET /agnesapi?video_id=<ID>` 轮询查询结果（间隔 5 秒）
5. 状态 `completed` 后，`remixed_from_video_id` 即为视频 URL

### 文本/图片理解（用户问"这张图是什么"）
1. 调用 `POST /v1/chat/completions` 使用 `agnes-2.0-flash`
2. messages 中 content 使用数组格式，含 `text` + `image_url`
